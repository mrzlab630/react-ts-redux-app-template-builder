/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-02-18
 * Time: 12:01
 * About:
 *
 */
import App from './App'


export default App