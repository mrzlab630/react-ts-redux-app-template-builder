import ErrorIndicator from './ErrorIndicator'

export default ErrorIndicator