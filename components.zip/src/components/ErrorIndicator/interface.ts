export interface IErrorIndicator {
    info?:string|number|false
}