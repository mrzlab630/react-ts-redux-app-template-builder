export interface IProps {
    children?:any
}

export interface IState {
    hasError?:any,
    error?: any,
    errorInfo?: any
}