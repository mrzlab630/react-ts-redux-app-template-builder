import appRoutes from './appRoutes'

export default appRoutes