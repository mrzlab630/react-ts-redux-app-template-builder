/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-02-18
 * Time: 13:47
 * About:
 *
 */
import {IappRoutes} from "../appRoutes/interface"


export interface ISwitcher {
    isAutheticated?:boolean,
    appRoutes:IappRoutes

}