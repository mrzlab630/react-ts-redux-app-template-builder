/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-05-30
 * Time: 15:08
 * About:
 *
 */


export interface IinitialStateHelpers{
    test?:string,
}





export const initialStateHelpers:IinitialStateHelpers = {
    test:'test'
}

