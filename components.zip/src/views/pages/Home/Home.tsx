/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-04-18
 * Time: 11:36
 * About:
 *
 */
import React, {FC} from "react"
import {IHome} from './interface'
import classes from './Home.module.scss'



const Home: FC<IHome> = () => {

    return <>Home</>
}

export default Home