/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-04-18
 * Time: 11:36
 * About:
 *
 */

import Home from './Home'

export default Home