/**
 *
 * by mrZ
 * Email: mrZ@mrZLab630.pw
 * Date: 2022-04-07
 * Time: 12:13
 * About:
 *
 */
import ErrorPage from './ErrorPage'

export default ErrorPage